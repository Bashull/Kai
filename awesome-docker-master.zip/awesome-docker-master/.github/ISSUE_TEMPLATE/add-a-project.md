---
name: Add a project
about: Add a new project to the list
title: add [PROJECT_NAME]
labels: pending-evaluation
assignees: ''

---

Repository link:
Description:
Author:

Or directly write it:

```markdown
[REPO](https://github.com/AUTHOR/REPO) - DESCRIPTION. By [@AUTHOR](https://github.com/AUTHOR)
```
