# Rails 8 (Basic Setup)

Provides practical, project-level rules and best practices for developing with Rails 8 using Cursor AI. Inspired by [Mawla/cursor_rules](https://github.com/Mawla/cursor_rules) — see that repository for further examples of Rails 8 Cursor rules.
