# ABP framework .cursorrules prompt file

Author: Berkan Sasmaz

Related Article: https://www.berkansasmaz.com/building-my-latest-project-with-asp-net-blazor-and-cursor-a-journey-to-abp
