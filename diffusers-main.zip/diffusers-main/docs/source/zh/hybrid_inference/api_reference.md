# 混合推理 API 参考

## 远程解码

[[autodoc]] utils.remote_utils.remote_decode

## 远程编码

[[autodoc]] utils.remote_utils.remote_encode