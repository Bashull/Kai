# Hybrid Inference API Reference

## Remote Decode

[[autodoc]] utils.remote_utils.remote_decode

## Remote Encode

[[autodoc]] utils.remote_utils.remote_encode
