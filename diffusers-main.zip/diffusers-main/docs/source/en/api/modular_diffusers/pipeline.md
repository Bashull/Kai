# Pipeline

## ModularPipeline

[[autodoc]] diffusers.modular_pipelines.modular_pipeline.ModularPipeline
