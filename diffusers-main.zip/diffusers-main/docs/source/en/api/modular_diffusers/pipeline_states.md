# Pipeline states

## PipelineState

[[autodoc]] diffusers.modular_pipelines.modular_pipeline.PipelineState

## BlockState

[[autodoc]] diffusers.modular_pipelines.modular_pipeline.BlockState 