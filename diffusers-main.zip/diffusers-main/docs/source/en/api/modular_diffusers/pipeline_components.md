# Components and configs

## ComponentSpec

[[autodoc]] diffusers.modular_pipelines.modular_pipeline.ComponentSpec

## ConfigSpec

[[autodoc]] diffusers.modular_pipelines.modular_pipeline.ConfigSpec

## ComponentsManager

[[autodoc]] diffusers.modular_pipelines.components_manager.ComponentsManager

## InsertableDict

[[autodoc]] diffusers.modular_pipelines.modular_pipeline_utils.InsertableDict