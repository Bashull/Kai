# Pipeline blocks

## ModularPipelineBlocks

[[autodoc]] diffusers.modular_pipelines.modular_pipeline.ModularPipelineBlocks

## SequentialPipelineBlocks

[[autodoc]] diffusers.modular_pipelines.modular_pipeline.SequentialPipelineBlocks

## LoopSequentialPipelineBlocks

[[autodoc]] diffusers.modular_pipelines.modular_pipeline.LoopSequentialPipelineBlocks

## AutoPipelineBlocks

[[autodoc]] diffusers.modular_pipelines.modular_pipeline.AutoPipelineBlocks