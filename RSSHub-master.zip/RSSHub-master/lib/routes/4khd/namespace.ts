import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '4KHD',
    url: 'www.4khd.com',
    description: '4KHD - HD Beautiful Girls',
    lang: 'en',
};
