import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'ABC News',
    url: 'abc.net.au',
    lang: 'en',
};
