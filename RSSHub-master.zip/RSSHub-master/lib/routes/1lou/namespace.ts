import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'BT 之家 1LOU 站',
    url: '1lou.me',
    categories: ['multimedia'],
    description: '',
    lang: 'zh-CN',
};
