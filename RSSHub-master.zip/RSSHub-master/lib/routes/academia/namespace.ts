import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'Academia',
    url: 'www.academia.edu',
    lang: 'en',
};
