import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '9To5',
    url: '9to5toys.com',
    lang: 'en',
};
