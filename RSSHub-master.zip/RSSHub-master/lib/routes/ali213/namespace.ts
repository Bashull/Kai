import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '游侠网',
    url: 'ali213.net',
    categories: ['game'],
    description: '',
    lang: 'zh-CN',
};
