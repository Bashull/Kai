import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '0xxx.ws',
    url: '0xxx.ws',
    categories: ['multimedia'],
    description: 'Best 0day Porn Source',
    lang: 'en',
};
