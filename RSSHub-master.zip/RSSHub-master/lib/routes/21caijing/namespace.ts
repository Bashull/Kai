import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '21财经',
    url: '21caijing.com',
    categories: ['finance'],
    description: '',
};
