import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'Backlinko',
    url: 'backlinko.com',
    lang: 'en',
};
