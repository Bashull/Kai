import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'Augment Code',
    url: 'augmentcode.com',
    categories: ['programming'],
    description: '',
    lang: 'en',
};
