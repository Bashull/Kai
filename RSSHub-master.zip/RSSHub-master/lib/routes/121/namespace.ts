import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '深圳台风网',
    url: '121.com.cn',
    categories: ['forecast'],
    description: '',
    lang: 'zh-CN',
};
