import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '爱发电',
    url: 'afdian.net',
    lang: 'zh-CN',
};
