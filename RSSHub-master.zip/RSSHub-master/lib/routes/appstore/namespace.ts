import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'App Store/Mac App Store',
    url: 'apps.apple.com',
    lang: 'en',
};
