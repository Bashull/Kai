import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'APKPure',
    url: 'apkpure.com',
    lang: 'en',
};
