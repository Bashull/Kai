import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'Alto - Toronto-Québec City High-Speed Rail Network',
    url: 'altotrain.ca',
    lang: 'en',
};
