import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '游戏星辰',
    url: 'www.2023game.com',
    lang: 'zh-CN',
};
