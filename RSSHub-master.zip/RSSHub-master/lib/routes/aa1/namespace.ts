import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '夏柔',
    url: 'aa1.cn',
    categories: ['new-media'],
    description: '',
    lang: 'zh-CN',
};
