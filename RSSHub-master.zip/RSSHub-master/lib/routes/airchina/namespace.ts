import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '中国国际航空公司',
    url: 'www.airchina.com.cn',
    lang: 'zh-CN',
};
