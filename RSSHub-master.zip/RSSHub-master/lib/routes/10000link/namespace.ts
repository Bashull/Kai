import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '10000万联网',
    url: '10000link.com',
    categories: ['new-media'],
    description: '',
    lang: 'zh-CN',
};
