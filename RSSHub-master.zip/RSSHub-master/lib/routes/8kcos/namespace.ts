import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '8KCosplay',
    url: '8kcosplay.com',
    lang: 'zh-CN',
};
