const SUB_NAME_PREFIX = '8KCosplay';
const SUB_URL = 'https://www.8kcosplay.com/';

export { SUB_NAME_PREFIX, SUB_URL };
