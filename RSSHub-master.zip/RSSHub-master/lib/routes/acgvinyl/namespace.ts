import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'ACG Vinyl - 黑胶',
    url: 'www.acgvinyl.com',
};
