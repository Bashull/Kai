import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'Anthropic',
    url: 'anthropic.com',
    lang: 'en',
};
