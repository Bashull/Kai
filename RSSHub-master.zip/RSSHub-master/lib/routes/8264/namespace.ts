import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '8264',
    url: '8264.com',
    lang: 'zh-CN',
};
