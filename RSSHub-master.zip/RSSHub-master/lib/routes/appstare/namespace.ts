import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'AppStare',
    url: 'appstare.net',
    lang: 'zh-CN',
};
