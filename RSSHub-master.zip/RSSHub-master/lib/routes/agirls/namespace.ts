import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '电獭少女',
    url: 'agirls.aotter.net',
    lang: 'zh-TW',
};
