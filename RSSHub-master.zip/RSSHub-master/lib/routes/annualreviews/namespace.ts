import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'Annual Reviews',
    url: 'annualreviews.org',
    lang: 'en',
};
