import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '阿里研究院',
    url: 'aliresearch.com',
    lang: 'zh-CN',
};
