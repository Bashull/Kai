import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'ACG17',
    url: 'acg17.com',
    lang: 'zh-CN',
};
