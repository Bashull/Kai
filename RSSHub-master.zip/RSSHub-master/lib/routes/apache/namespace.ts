import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'Apache',
    url: 'apisix.apache.org',
    lang: 'en',
};
