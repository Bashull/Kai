import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'AtCoder',
    url: 'atcoder.jp',
    lang: 'en',
};
