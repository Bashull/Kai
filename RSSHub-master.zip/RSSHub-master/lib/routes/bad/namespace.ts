import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'Bad.news',
    url: 'bad.news',
    lang: 'zh-CN',
};
