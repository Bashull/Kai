import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '52hrtt 华人头条',
    url: '52hrtt.com',
    lang: 'zh-CN',
};
