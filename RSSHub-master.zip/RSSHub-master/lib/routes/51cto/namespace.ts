import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '51CTO',
    url: '51cto.com',
    lang: 'zh-CN',
};
