import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '5EPLAY',
    url: 'csgo.5eplay.com',
    lang: 'zh-CN',
};
