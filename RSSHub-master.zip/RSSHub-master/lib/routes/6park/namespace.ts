import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '留园网',
    url: 'club.6parkbbs.com',
    lang: 'zh-CN',
};
