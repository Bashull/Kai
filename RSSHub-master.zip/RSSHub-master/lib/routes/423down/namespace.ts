import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '423Down',
    url: '423down.com',
    categories: ['program-update'],
    description: '',
    lang: 'zh-CN',
};
