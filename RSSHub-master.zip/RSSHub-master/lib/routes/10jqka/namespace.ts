import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '同花顺财经',
    url: '10jqka.com.cn',
    categories: ['finance'],
    description: '',
    lang: 'zh-CN',
};
