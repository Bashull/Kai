import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'AIbase',
    url: 'aibase.com',
    categories: ['new-media'],
    description: '',
    lang: 'zh-CN',
};
