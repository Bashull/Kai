import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'AGE 动漫',
    url: 'agemys.cc',
    lang: 'zh-CN',
};
