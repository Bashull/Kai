import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'A9VG 电玩部落',
    url: 'a9vg.com',
    description: '',
    lang: 'zh-CN',
};
