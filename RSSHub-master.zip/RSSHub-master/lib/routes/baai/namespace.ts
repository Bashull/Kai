import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '北京智源人工智能研究院',
    url: 'hub.baai.ac.cn',
    lang: 'zh-CN',
};
