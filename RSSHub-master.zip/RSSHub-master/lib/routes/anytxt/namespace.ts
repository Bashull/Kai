import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'Anytxt Searcher',
    url: 'anytxt.net',
    categories: ['program-update'],
    description: '',
    lang: 'zh-CN',
};
