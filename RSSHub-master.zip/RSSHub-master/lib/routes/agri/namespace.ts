import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '中国农业农村信息网',
    url: 'agri.cn',
    categories: ['new-media'],
    description: '',
    lang: 'zh-CN',
};
