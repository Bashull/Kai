import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'Access Briefing',
    url: 'accessbriefing.com',
    categories: ['new-media'],
    description: '',
    lang: 'en',
};
