import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '2048 核基地',
    url: 'hjd2048.com',
    lang: 'zh-CN',
};
