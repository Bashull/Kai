import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'ALICESOFT',
    url: 'www.alicesoft.com',
    lang: 'ja',
};
