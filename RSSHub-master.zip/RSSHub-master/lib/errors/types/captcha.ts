class CaptchaError extends Error {
    name = 'CaptchaError';
}

export default CaptchaError;
