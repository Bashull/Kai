-- Alter the enum type "TeamMemberRole" to "TeamAccessRole"
ALTER TYPE "TeamMemberRole" RENAME TO "TeamAccessRole";
