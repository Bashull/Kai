-- AlterTable
ALTER TABLE "TeamCollection" ADD COLUMN     "data" JSONB;

-- AlterTable
ALTER TABLE "UserCollection" ADD COLUMN     "data" JSONB;
