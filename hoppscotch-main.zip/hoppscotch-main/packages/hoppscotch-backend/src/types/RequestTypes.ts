export enum ReqType {
  REST = 'REST',
  GQL = 'GQL',
}
