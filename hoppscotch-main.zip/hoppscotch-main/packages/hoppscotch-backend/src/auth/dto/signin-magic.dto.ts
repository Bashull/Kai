// Inputs to initiate Magic-Link auth flow
export class SignInMagicDto {
  email: string;
}
