// Inputs to create a new PAT
export class CreateAccessTokenDto {
  label: string;
  expiryInDays: number | null;
}
