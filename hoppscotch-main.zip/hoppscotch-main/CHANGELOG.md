# Changelog

Visit [releases](https://github.com/hoppscotch/hoppscotch/releases) for full changelog.
